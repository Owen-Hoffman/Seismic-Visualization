
#ifndef UTIL_H
#define UTIL_H 1

extern int  gen_log(int level, int verb, ... );
extern void safe_usleep (unsigned long int useconds);

#endif
